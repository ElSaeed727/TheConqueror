package exceptions;

public class BuildingInCoolDownException extends BuildingException {
	
	public BuildingInCoolDownException(){
		super();
	}
	public BuildingInCoolDownException(String s) {
		super(s);
	}
	
}
