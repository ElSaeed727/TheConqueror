package exceptions;

public class MaxLevelException extends BuildingException {
	
	public MaxLevelException(){
		super();
	}
	public MaxLevelException(String s) {
		super(s);
	}
	
}
