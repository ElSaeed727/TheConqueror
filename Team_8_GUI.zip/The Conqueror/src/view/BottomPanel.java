package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.*;

public class BottomPanel extends JPanel {

	private JButton endTurnButton;
	private JButton marchingArmiesButton;
	
	public BottomPanel() {
		super();
		setMaximumSize(new Dimension(800,100));
		endTurnButton = new JButton("End Turn");
		endTurnButton.setBackground(new Color(235,0,0));
		marchingArmiesButton = new JButton("Marching Armies");
		add(marchingArmiesButton);
		add(endTurnButton);
	}
	
	public JButton getEndTurnButton() {
		return endTurnButton;
	}
	
	public JButton getMarchingArmiesButton() {
		return marchingArmiesButton;
	}
	
}
