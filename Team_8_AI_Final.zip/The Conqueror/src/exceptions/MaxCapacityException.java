package exceptions;

public class MaxCapacityException extends ArmyException {
	
	public MaxCapacityException(){
		super();
	}
	public MaxCapacityException(String s) {
		super(s);
	}
	
}
