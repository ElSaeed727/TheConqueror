package exceptions;

public class FriendlyCityException extends ArmyException {
	
	public FriendlyCityException() {
		super();
	}
	public FriendlyCityException(String s) {
		super(s);
	}
	
}
