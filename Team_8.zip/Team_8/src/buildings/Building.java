package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;

public abstract class Building {
	
	// Attributes
	private int cost; // Read only
	private int level = 1;
	private int upgradeCost;
	private boolean coolDown = true;
	
	public int getCost() {
		return cost;
	}
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	
	public int getUpgradeCost() {
		return upgradeCost;
	}
	public void setUpgradeCost(int upgradeCost) {
		this.upgradeCost = upgradeCost;
	}
	
	public boolean isCoolDown() {
		return coolDown;
	}
	public void setCoolDown(boolean coolDown) {
		this.coolDown = coolDown;
	}
	
	// Constructors
	public Building(int cost, int upgradeCost) {
		this.cost = cost;
		this.upgradeCost = upgradeCost;
	}
	
	// Methods
	public void upgrade() throws BuildingInCoolDownException, MaxLevelException {
		if(level==3)
			throw new MaxLevelException("Building is already at maximum level");
		if(coolDown)
			throw new BuildingInCoolDownException("Building is in cool down");
		level++;
		coolDown = true;
	}
}
