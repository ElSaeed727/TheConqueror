package exceptions;

abstract public class ArmyException extends EmpireException {
	
	public ArmyException(){
		super();
	}
	public ArmyException(String s) {
		super(s);
	}
	
}
