package view;

public interface WindowClosingListener {
	void onWindowClosed();
}
