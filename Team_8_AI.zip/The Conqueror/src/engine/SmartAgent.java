package engine;

import java.util.ArrayList;
import java.util.Arrays;

import buildings.ArcheryRange;
import buildings.Barracks;
import buildings.Building;
import buildings.Farm;
import buildings.Market;
import buildings.Stable;
import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import exceptions.NotEnoughGoldException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Unit;

public class SmartAgent extends Player{
	
	
	//moves
	//[Build Farm, build Market, build ArcheryRange, build Barracks, build Stable, Upgrade Farm, Upgrade Market, Upgrade, Barracks, Upgrade Market ]
	
	// Constructor
	public SmartAgent() {
		super("AI");
	}
	// Methods
	public static double minmax(SmartAgent AI,int depth, int turnCount, int[] moves) throws NotEnoughGoldException, BuildingInCoolDownException, MaxLevelException, MaxRecruitedException {
		
		AI.execute(moves);
		if(depth == 0 || turnCount == 50) {
			return positonEval(AI);
		}
		
		
		double maxEval = Double.NEGATIVE_INFINITY;
		int[] bestMove = {0,0,0,0,0,0,0,0,0,0,0,0,0};
		 ArrayList<int[]> allMoves = AI.generateMoves();
		for(int[] m : allMoves) {
			double currentEval = minmax(clone(AI),depth-1,turnCount+1,m);
			if(currentEval > maxEval) {
				maxEval = currentEval;
				bestMove = m;
			}
			AI.execute(bestMove);
			return maxEval;
		}
		
		return 0;
	}
	
	
	
	public static double positonEval(Player AI) {
		double eval = 0;
		
		int total = 0;
		double nCav = 0;
		double nInf = 0;
		double nArc = 0;
		double idealCav = 0.6;
		double idealInf = 0.25;
		double idealArc = 0.15;
		
		ArrayList<Army> defendingArmies = new ArrayList<Army>();
		for(City c : AI.getControlledCities()) {
			defendingArmies.add(c.getDefendingArmy());
		}
		defendingArmies.addAll(AI.getControlledArmies());
		
		for(Army A : defendingArmies) {
			for(Unit U : A.getUnits()) {
				if(U instanceof Infantry)
					nInf++;
				if(U instanceof Archer)
					nArc++;
				if(U instanceof Cavalry)
					nCav++;
				total++;
			}
		}
		nCav = 1+(idealCav - nCav/total);
		nInf = 1+(idealInf - nInf/total);
		nArc = 1+(idealArc - nArc/total);
		
		
		for(Army A : defendingArmies) {
			for(Unit U : A.getUnits()) {
				if(U instanceof Archer)
					eval += ratio(U)*modifier(U)*nArc;
				if(U instanceof Infantry)
					eval += ratio(U)*modifier(U)*nInf;
				if(U instanceof Cavalry)
					eval += ratio(U)*modifier(U)*nCav;
			}
		}
		
		return eval;
	}
	
	private static double ratio(Unit unit) { 
		return (double)(unit.getCurrentSoldierCount())/unit.getMaxSoldierCount();
	}
	private static double modifier(Unit unit) { 
		if(unit instanceof Archer) {
			switch(unit.getLevel()) {
				case 1: return 1;
				case 2: return 1.2;
				case 3: return 1.4;
			}
		}
		else if(unit instanceof Infantry) {
			switch(unit.getLevel()) {
				case 1: return 1.2;
				case 2: return 1.4;
				case 3: return 1.7;
			}
		}
		else if(unit instanceof Cavalry) {
			switch(unit.getLevel()) {
				case 1: return 1.4;
				case 2: return 1.6;
				case 3: return 2;
			}
		}
		return 0;
	}
	public int canBuilding(String building, int deduction) {
		ArrayList<Building> buildings = new ArrayList<Building>();
		for(City c : this.getControlledCities()) {
			buildings.addAll(c.getEconomicalBuildings());
			buildings.addAll(c.getMilitaryBuildings());
		}
		boolean exists = false;
		for(Building b : buildings) {
			switch(building) {
			case "Farm": if(b instanceof Farm) exists = true;break;
			case "Market": if(b instanceof Market) exists = true;break;
			case "ArcheryRange": if(b instanceof ArcheryRange) exists = true;break;
			case "Barracks": if(b instanceof Barracks) exists = true;break;
			case "Stable": if(b instanceof Stable) exists = true;break;
			}
		}
		
		if(exists == true) // Building is already built
			return -1;
		
		switch(building) {
		case "Farm": if(this.getTreasury() - deduction >= 1000)  return 1000; else return -1;
		case "Market": if(this.getTreasury() - deduction >= 1500)  return 1500; else return -1;
		case "ArcheryRange": if(this.getTreasury() - deduction >= 1500)  return 1500; else return -1;
		case "Barracks": if(this.getTreasury() - deduction >= 2000)  return 2000; else return -1;
		case "Stable": if(this.getTreasury() - deduction >= 2500)  return 2500; else return -1;
		}
		
		return -1;
	}
	public int canUpgrade(String name, int deduction) {
		ArrayList<Building> buildings = new ArrayList<Building>();
		for(City c : this.getControlledCities()) {
			buildings.addAll(c.getEconomicalBuildings());
			buildings.addAll(c.getMilitaryBuildings());
		}
		
		Building building = null;
		
		for(Building b : buildings) {
			switch(name) {
			case "Farm": if(b instanceof Farm) building  = b;break;
			case "Market": if(b instanceof Market) building  = b;break;
			case "ArcheryRange": if(b instanceof ArcheryRange) building  = b;break;
			case "Barracks": if(b instanceof Barracks) building  = b;break;
			case "Stable": if(b instanceof Stable) building  = b;break;
			}
		}
		
		if(building == null || building.getLevel() == 3 || building.isCoolDown()) { //Building doesnt exist or exists but can upgrade from 3 to 4 or in cooldown
			return -1;
		}
		if(building.getUpgradeCost() > this.getTreasury() - deduction ) { // Cannot afford upgrade
			return -1;
		}
		return building.getUpgradeCost();
	}
	public int canRecruit(String unit, int number, int deduction) {
		ArrayList<Building> buildings = new ArrayList<Building>();
		for(City c : this.getControlledCities()) {
			buildings.addAll(c.getMilitaryBuildings());
		}
		
		Building building = null;
		
		for(Building b : buildings) {
			switch(unit) {
			case "Archer": if(b instanceof ArcheryRange) building  = b;break;
			case "Infantry": if(b instanceof Barracks) building  = b;break;
			case "Cavalry": if(b instanceof Stable) building  = b;break;
			}
		}
		if(building == null) // Building does exist
			return -1;
		if(building.isCoolDown()) // Building in Cooldown
			return -1;
		
		switch(unit) {
		case "Infantry" :  if(this.getTreasury() - deduction >= number*(((Barracks)building).getRecruitmentCost())) return number*((Barracks)building).getRecruitmentCost(); else return -1  ;
		case "Archer" :  if(this.getTreasury() - deduction >= number*(((ArcheryRange)building).getRecruitmentCost())) return number*((ArcheryRange)building).getRecruitmentCost(); else return -1  ;
		case "Cavalry" :  if(this.getTreasury() - deduction >= number*(((Stable)building).getRecruitmentCost())) return number*((Stable)building).getRecruitmentCost(); else return -1  ;
		}
		
		return -1;
		
	}
	public int[] possibleMoves(){
		//moves
		//[Build Farm, build Market, build ArcheryRange, build Barracks, build Stable, Upgrade Farm, Upgrade Market, Upgrade, Barracks, Upgrade Market,Cav,Inf,Arc ]
		int[] move = {0,0,0,0,0,0,0,0,0,0,0,0,0};
		if(canBuilding("Farm",0) != -1) {
			move[0] = 1;
		}
		if(canBuilding("Market",0) != -1) {
			move[1] = 1;
		}
		if(canBuilding("ArcheryRange",0) != -1) {
			move[2] = 1;
		}
		if(canBuilding("Barracks",0) != -1) {
			move[3] = 1;
		}
		if(canBuilding("Stable",0) != -1) {
			move[4] = 1;
		}
		
		if(canUpgrade("Farm",0) != -1) {
			move[5] = 1;
		}
		if(canUpgrade("Market",0) != -1) {
			move[6] = 1;
		}
		if(canUpgrade("ArcheryRange",0) != -1) {
			move[7] = 1;
		}
		if(canUpgrade("Barracks",0) != -1) {
			move[8] = 1;
		}
		if(canUpgrade("Stable",0) != -1) {
			move[9] = 1;
		}
		
		if(canRecruit("Cavalry",3,0) != -1)
			move[10] = 3;
		else 
			if(canRecruit("Cavalry",2,0) != -1)
			move[10] = 2;
		else
			if(canRecruit("Cavalry",1,0) != -1)
			move[10] = 1;
		
		if(canRecruit("Infantry",3,0) != -1)
			move[11] = 3;
		else 
			if(canRecruit("Infantry",2,0) != -1)
			move[11] = 2;
		else
			if(canRecruit("Infantry",1,0) != -1)
			move[11] = 1;
		
		if(canRecruit("Archer",3,0) != -1)
			move[12] = 3;
		else 
			if(canRecruit("Archer",2,0) != -1)
			move[12] = 2;
		else
			if(canRecruit("Archer",1,0) != -1)
			move[12] = 1;
		
		return move;
	}
	private static boolean compare(int[] A, int[] B) {
		if(A.length != B.length)
			return false;
		for(int i = 0; i<A.length ; i++) {
			if(A[i] != B[i])
				return false;
		}
		return true;
	}
	private static boolean MoveNotMade(int[] move, ArrayList<int[]> allMoves ) {
		for(int[] m : allMoves) {
			if(compare(m,move) == true)
				return false;
		}
		return true;
	}
	private ArrayList<int[]> generateMoves(){
		
		int[] moves = possibleMoves();
		
		ArrayList<int[]> allPossible = new ArrayList<int[]>();
		ArrayList<int[]> allRealPossible = new ArrayList<int[]>();
		
		allPossible = genSequence(moves);
		
		for(int[] m : allPossible) {
			m = genReal(m);
			if(MoveNotMade(m,allRealPossible)) {
				allRealPossible.add(m);
			}
		}
		
		return allPossible;
	}
	private static ArrayList<int[]> genSequence(int[] max){
    	ArrayList<int[]> a = new ArrayList<>();
    	genSequence(a,new int[max.length],max);
    	return a;
    }

    private static void genSequence(ArrayList<int[]> a, int[] curr, int[] max){
    	a.add(curr.clone());
    	if(Arrays.equals(curr,max))
    		return;
    	int index = curr.length-1;
    	curr[index]++;
    	while(index>=0 && curr[index]>max[index]){
    		curr[index] = 0;
    		index--;
    		if(index>=0)
    			curr[index]++;
    	}
    	genSequence(a,curr,max);
    }
    private int[] genReal(int[] moves) { 
    	int[] realMoves = {0,0,0,0,0,0,0,0,0,0,0,0,0};
    	int deduction = 0;
    	int cost = 0;
    	
    	if(moves[0] == 1) {
    		cost = this.canBuilding("Farm", deduction);
			if(cost != -1) {
				moves[0] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
    	if(moves[1] == 1) {
    		cost = this.canBuilding("Market", deduction);
			if(cost != -1) {
				moves[1] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
    	if(moves[2] == 1) {
    		cost = this.canBuilding("ArcheryRange", deduction);
			if(cost != -1) {
				moves[2] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
    	if(moves[3] == 1) {
    		cost = this.canBuilding("Barracks", deduction);
			if(cost != -1) {
				moves[3] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
    	if(moves[4] == 1) {
    		cost = this.canBuilding("Stable", deduction);
			if(cost != -1) {
				moves[4] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[5] == 1) {
			cost = this.canUpgrade("Farm", deduction);
			if(cost != -1) {
				moves[5] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[6] == 1) {
			cost = this.canUpgrade("Market", deduction);
			if(cost != -1) {
				moves[6] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[7] == 1) {
			cost = this.canUpgrade("ArcheryRange", deduction);
			if(cost != -1) {
				moves[7] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[8] == 1) {
			cost = this.canUpgrade("Barracks", deduction);
			if(cost != -1) {
				moves[8] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[9] == 1) {
			cost = this.canUpgrade("Stable", deduction);
			if(cost != -1) {
				moves[9] = 1;
			}
			else {
				return moves;
			}
			deduction += cost;
		}
		if(moves[10] != 0) {
			for(int i = 0; i < moves[10] ; i++) {
				cost = this.canRecruit("Cavalry", 1, deduction);
				if(cost != -1) {
					moves[10] += 1;
				}
				else {
					return moves;
				}
				deduction += cost;
			}
		}
		if(moves[11] != 0) {
			for(int i = 0; i < moves[11] ; i++) {
				cost = this.canRecruit("Infantry", 1, deduction);
				if(cost != -1) {
					moves[11] += 1;
				}
				else {
					return moves;
				}
				deduction += cost;
			}
		}
		if(moves[12] != 0) {
			for(int i = 0; i < moves[12] ; i++) {
				cost = this.canRecruit("Archer", 1, deduction);
				if(cost != -1) {
					moves[12] += 1;
				}
				else {
					return moves;
				}
				deduction += cost;
			}
		}
		
		return realMoves;
    }
	public void execute(int[] moves) throws NotEnoughGoldException, BuildingInCoolDownException, MaxLevelException, MaxRecruitedException {
		String cityName = this.getControlledCities().get(0).getName();
		
		if(moves[0] == 1) {
			this.build("Farm", cityName);
		}
		if(moves[1] == 1) {
			this.build("Market", cityName);
		}
		if(moves[2] == 1) {
			this.build("ArcheryRange", cityName);
		}
		if(moves[3] == 1) {
			this.build("Barracks", cityName);
		}
		if(moves[4] == 1) {
			this.build("Stable", cityName);
		}
		if(moves[5] == 1) {
			this.upgradeBuildingByName("Farm", cityName);
		}
		if(moves[6] == 1) {
			this.upgradeBuildingByName("Market", cityName);
		}
		if(moves[7] == 1) {
			this.upgradeBuildingByName("ArcheryRange", cityName);
		}
		if(moves[8] == 1) {
			this.upgradeBuildingByName("Barracks", cityName);
		}
		if(moves[9] == 1) {
			this.upgradeBuildingByName("Stable", cityName);
		}
		if(moves[10] != 0) {
			for(int i = 0; i < moves[10] ; i++)
				this.recruitUnit("Archer", cityName);
		}
		if(moves[11] != 0) {
			for(int i = 0; i < moves[11] ; i++)
				this.recruitUnit("Infantry", cityName);
		}
		if(moves[12] != 0) {
			for(int i = 0; i < moves[12] ; i++)
				this.recruitUnit("Cavalry", cityName);
		}
	}
	public static void test(SmartAgent AI) throws NotEnoughGoldException, BuildingInCoolDownException, MaxLevelException, MaxRecruitedException {
		int[] move = {1,1,1,1,1,0,0,0,0,0,0,0,0,0,0};
		AI.execute(move);
		return;
	}
	public static SmartAgent clone(SmartAgent AI) {
		SmartAgent clone = new SmartAgent();
		
		for(City c : AI.getControlledCities()) {
			clone.getControlledCities().add(City.clone(c));
		}
		for(Army a : AI.getControlledArmies()) {
			clone.getControlledArmies().add(Army.clone(a));
		}
		clone.setTreasury(AI.getTreasury());
		clone.setFood(AI.getFood());
		
		return clone;
//		private PlayerListener playerListener;
	}
	
	// Test
	public static void main(String[] args) throws NotEnoughGoldException, BuildingInCoolDownException, MaxLevelException, MaxRecruitedException {
		
		SmartAgent AI = new SmartAgent();
		int[] moves = {1,1,1,1,1,0,0,0,0,0,0,0,0,0,0};
		AI.setTreasury(50000);
		City rome = new City("Rome");
		AI.getControlledCities().add(rome);
		AI.execute(moves);
		System.out.println(rome.getMilitaryBuildings().size());
		System.out.println(rome.getEconomicalBuildings().size());
//		SmartAgent AI2 = clone(AI);
//		System.out.println(AI.getTreasury());
//		System.out.println(AI2.getTreasury());
//		System.out.println(AI2.getControlledCities().get(0).getDefendingArmy().getUnits());
		
//		int[] realMove = AI.genReal(moves);
//		System.out.print(Arrays.toString(realMove));
		
//		System.out.print(Arrays.toString(AI.possibleMoves()));
		
//		ArrayList<int[]> nums = AI.generateMoves();
//		for(int[] a : nums){
//    		System.out.println(Arrays.toString(a));
//    	}
		
//		AI.execute(moves);
		
//		test(AI);
//		System.out.println(AI.getControlledCities().get(0).getEconomicalBuildings().get(0));
//		System.out.println(AI.getControlledCities().get(0).getMilitaryBuildings().get(0));
//		System.out.println(AI.getTreasury());
		
		
	}

}
