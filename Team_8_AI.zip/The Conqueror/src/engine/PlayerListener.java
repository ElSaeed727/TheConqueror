package engine;

public interface PlayerListener {
	void onTreasuryChanged(double treasury);
	void onFoodChanged(double food);
}
